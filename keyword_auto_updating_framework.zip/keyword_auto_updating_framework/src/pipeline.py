"""
Golden-dataset curation pipeline.

Orchestrates:
  1. Sentence-transformer (ST) classification of each silver-dataset sample.
  2. LLM arbitration when human label and ST prediction disagree.
  3. Keyword-list updates based on LLM verdict.
  4. Periodic ST model refresh every KEYWORD_UPDATE_INTERVAL new keywords.
  5. Routing of LLM-unclear samples to separate holding files.
  6. Post-loop convergence pass: iterates until ST achieves 100% accuracy on
     the golden dataset, or MAX_CONVERGENCE_PASSES is reached.

Case taxonomy
-------------
AGREEMENT        human == ST          -> add to golden; no LLM call
ST_FALSE_NEGATIVE  LLM=HSHD  / human=HSHD     / ST=Not HSHD  (Case 3)
                   -> add LLM keyword as HSHD; add sample to golden
WRONG_LABEL_FP     LLM=HSHD  / human=Not HSHD / ST=HSHD       (Case 4)
                   -> no keyword change; add to golden with LLM-corrected label
ST_FALSE_POSITIVE  LLM=Not HSHD / human=Not HSHD / ST=HSHD    (Case 5)
                   -> add LLM keyword as Not HSHD; add sample to golden
WRONG_LABEL_FN     LLM=Not HSHD / human=HSHD     / ST=Not HSHD (Case 6)
                   -> no keyword change; add to golden with LLM-corrected label
LLM_OVERRIDE       all other combos
                   -> add keyword; add to golden
UNCLEAR            LLM returns "unclear"
                   -> write to unknown_silver_dataset; write keyword to
                      unclear_keywords; skip golden dataset; no keyword-list update
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

import pandas as pd

from .llm_judge import LLMJudge
from .sentence_transformer_classifier import SentenceTransformerClassifier

logger = logging.getLogger(__name__)

KEYWORD_UPDATE_INTERVAL = 5
MAX_CONVERGENCE_PASSES  = 10


class CaseType(str, Enum):
    AGREEMENT_HSHD     = "AGREEMENT_HSHD"
    AGREEMENT_NOT_HSHD = "AGREEMENT_NOT_HSHD"
    ST_FALSE_NEGATIVE  = "ST_FALSE_NEGATIVE"   # Case 3
    WRONG_LABEL_FP     = "WRONG_LABEL_FP"      # Case 4
    ST_FALSE_POSITIVE  = "ST_FALSE_POSITIVE"   # Case 5
    WRONG_LABEL_FN     = "WRONG_LABEL_FN"      # Case 6
    LLM_OVERRIDE       = "LLM_OVERRIDE"
    UNCLEAR            = "UNCLEAR"


@dataclass
class PipelineResult:
    golden_df:          pd.DataFrame
    keyword_df:         pd.DataFrame
    unknown_silver_df:  pd.DataFrame   # unclear samples for human review
    unclear_keywords_df: pd.DataFrame  # LLM-flagged keywords for human review
    final_accuracy:     float
    convergence_passes: int


class Pipeline:
    def __init__(
        self,
        st_classifier: SentenceTransformerClassifier,
        llm_judge:     LLMJudge,
    ):
        self.st  = st_classifier
        self.llm = llm_judge

        self._golden:            list[dict] = []
        self._unknown_silver:    list[dict] = []
        self._unclear_keywords:  list[dict] = []
        self._kw_updates_since_refresh: int = 0

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(self, silver_df: pd.DataFrame, keyword_df: pd.DataFrame) -> PipelineResult:
        self._keyword_df = keyword_df.copy()
        self._golden             = []
        self._unknown_silver     = []
        self._unclear_keywords   = []
        self._kw_updates_since_refresh = 0

        self.st.load_keyword_list(self._keyword_df)

        logger.info("=" * 60)
        logger.info("PHASE 1: Processing %d silver-dataset samples", len(silver_df))
        logger.info("=" * 60)

        for _, row in silver_df.iterrows():
            self._process_row(row)

        if self._kw_updates_since_refresh > 0:
            logger.info("Final keyword-list refresh (%d pending).", self._kw_updates_since_refresh)
            self.st.load_keyword_list(self._keyword_df)
            self._kw_updates_since_refresh = 0

        golden_df = pd.DataFrame(self._golden)

        # ------------------------------------------------------------------
        # PHASE 2: convergence loop
        # ------------------------------------------------------------------
        golden_df, convergence_passes = self._convergence_loop(golden_df)

        eval_result = self.st.evaluate(golden_df)
        logger.info(
            "Final ST accuracy: %.1f%% (%d/%d) after %d convergence pass(es).",
            eval_result["accuracy"] * 100,
            int(eval_result["accuracy"] * eval_result["total"]),
            eval_result["total"],
            convergence_passes,
        )

        return PipelineResult(
            golden_df           = golden_df,
            keyword_df          = self._keyword_df,
            unknown_silver_df   = pd.DataFrame(self._unknown_silver),
            unclear_keywords_df = pd.DataFrame(self._unclear_keywords),
            final_accuracy      = eval_result["accuracy"],
            convergence_passes  = convergence_passes,
        )

    # ------------------------------------------------------------------
    # Per-row processing
    # ------------------------------------------------------------------

    def _process_row(self, row: pd.Series) -> None:
        source_input: str = str(row["source_input"])
        human_label:  str = str(row["human_label"])

        st_result = self.st.classify(source_input)
        st_label  = st_result.label
        st_kw     = st_result.most_similar_keyword or ""
        st_score  = st_result.similarity_score

        logger.info(
            "  [%-28s]  human=%-10s  ST=%-10s  (closest: '%s', %.4f)",
            source_input, human_label, st_label, st_kw, st_score,
        )

        # Agreement: skip LLM
        if human_label == st_label:
            case = (
                CaseType.AGREEMENT_HSHD
                if human_label == "HSHD"
                else CaseType.AGREEMENT_NOT_HSHD
            )
            self._append_golden(
                source_input=source_input, human_label=human_label,
                st_label=st_label, st_kw=st_kw, st_score=st_score,
                llm_label=None, llm_reasoning="Human and ST agree — no LLM call.",
                llm_keyword=None, case=case, final_label=human_label,
            )
            return

        # Disagreement: invoke LLM
        similar_golden = self.st.get_similar_golden_samples(
            source_input, self._golden, top_k=3
        )
        llm_result  = self.llm.judge(
            source_input=source_input,
            human_label=human_label,
            st_label=st_label,
            st_most_similar_kw=st_kw,
            st_similarity_score=st_score,
            similar_golden_samples=similar_golden,
        )
        llm_label   = llm_result["label"]
        llm_reason  = llm_result.get("reasoning", "")
        llm_keyword = llm_result.get("generated_keyword", source_input)

        # ------ UNCLEAR branch ----------------------------------------
        if llm_label == "unclear":
            logger.info(
                "    LLM=unclear -> routing to unknown_silver / unclear_keywords."
            )
            self._unknown_silver.append({
                "source_input":        source_input,
                "human_label":         human_label,
                "st_label":            st_label,
                "st_most_similar_kw":  st_kw,
                "st_similarity_score": st_score,
                "llm_reasoning":       llm_reason,
                "llm_generated_kw":    llm_keyword,
            })
            self._unclear_keywords.append({
                "keyword":   llm_keyword,
                "source_input": source_input,
                "llm_reasoning": llm_reason,
            })
            return   # do NOT add to golden or update keyword list

        # ------ Classified branch -------------------------------------
        case = self._determine_case(human_label, st_label, llm_label)

        logger.info(
            "    LLM=%-10s  case=%-22s  generated_kw='%s'",
            llm_label, case.value, llm_keyword,
        )

        self._handle_keyword_update(case, llm_keyword, llm_label)
        self._append_golden(
            source_input=source_input, human_label=human_label,
            st_label=st_label, st_kw=st_kw, st_score=st_score,
            llm_label=llm_label, llm_reasoning=llm_reason,
            llm_keyword=llm_keyword, case=case, final_label=llm_label,
        )

    # ------------------------------------------------------------------
    # Case determination
    # ------------------------------------------------------------------

    @staticmethod
    def _determine_case(human_label: str, st_label: str, llm_label: str) -> CaseType:
        h, s, l_ = human_label, st_label, llm_label
        if l_ == "HSHD"     and h == "HSHD"     and s == "Not HSHD": return CaseType.ST_FALSE_NEGATIVE
        if l_ == "HSHD"     and h == "Not HSHD" and s == "HSHD":     return CaseType.WRONG_LABEL_FP
        if l_ == "Not HSHD" and h == "Not HSHD" and s == "HSHD":     return CaseType.ST_FALSE_POSITIVE
        if l_ == "Not HSHD" and h == "HSHD"     and s == "Not HSHD": return CaseType.WRONG_LABEL_FN
        return CaseType.LLM_OVERRIDE

    # ------------------------------------------------------------------
    # Keyword-list updates
    # ------------------------------------------------------------------

    def _handle_keyword_update(
        self, case: CaseType, generated_keyword: str, llm_label: str
    ) -> None:
        """
        Modifies keyword list for:   ST_FALSE_NEGATIVE, ST_FALSE_POSITIVE, LLM_OVERRIDE
        No-ops for:                  WRONG_LABEL_FP, WRONG_LABEL_FN  (ST was correct)
        """
        if case not in (
            CaseType.ST_FALSE_NEGATIVE,
            CaseType.ST_FALSE_POSITIVE,
            CaseType.LLM_OVERRIDE,
        ):
            return

        if not generated_keyword:
            return

        existing = self._keyword_df["keyword"].str.lower().tolist()
        if generated_keyword.lower() in existing:
            logger.info("    Keyword '%s' already exists — skipping.", generated_keyword)
            return

        new_row = pd.DataFrame([{
            "keyword": generated_keyword,
            "label":   llm_label,
            "source":  "LLM_generated",
        }])
        self._keyword_df = pd.concat([self._keyword_df, new_row], ignore_index=True)
        self._kw_updates_since_refresh += 1

        logger.info(
            "    Added [%-10s] '%s'. Updates since refresh: %d/%d",
            llm_label, generated_keyword,
            self._kw_updates_since_refresh, KEYWORD_UPDATE_INTERVAL,
        )

        if self._kw_updates_since_refresh >= KEYWORD_UPDATE_INTERVAL:
            logger.info("    Refreshing ST embeddings …")
            self.st.load_keyword_list(self._keyword_df)
            self._kw_updates_since_refresh = 0

    # ------------------------------------------------------------------
    # Golden-dataset append
    # ------------------------------------------------------------------

    def _append_golden(
        self,
        source_input: str, human_label: str,
        st_label: str, st_kw: str, st_score: float,
        llm_label: Optional[str], llm_reasoning: str, llm_keyword: Optional[str],
        case: CaseType, final_label: str,
    ) -> None:
        self._golden.append({
            "source_input":        source_input,
            "human_label":         human_label,
            "st_label":            st_label,
            "st_most_similar_kw":  st_kw,
            "st_similarity_score": st_score,
            "llm_label":           llm_label or "",
            "llm_reasoning":       llm_reasoning,
            "llm_generated_kw":    llm_keyword or "",
            "case_type":           case.value,
            "final_label":         final_label,
        })

    # ------------------------------------------------------------------
    # Convergence loop
    # ------------------------------------------------------------------

    def _convergence_loop(
        self, golden_df: pd.DataFrame
    ) -> tuple[pd.DataFrame, int]:
        logger.info("")
        logger.info("=" * 60)
        logger.info("PHASE 2: Convergence loop (target: 100%% ST accuracy)")
        logger.info("=" * 60)

        for pass_num in range(1, MAX_CONVERGENCE_PASSES + 1):
            eval_result = self.st.evaluate(golden_df)
            accuracy    = eval_result["accuracy"]
            errors      = eval_result["errors"]

            logger.info(
                "  Pass %d — accuracy %.1f%% (%d errors)",
                pass_num, accuracy * 100, len(errors),
            )

            if accuracy == 1.0:
                logger.info("  Converged after %d pass(es).", pass_num - 1)
                return golden_df, pass_num - 1

            for err in errors:
                source_input = err["source_input"]
                expected     = err["expected"]
                predicted    = err["predicted"]

                logger.info(
                    "    Fixing '%s': ST=%s expected=%s",
                    source_input, predicted, expected,
                )

                st_result  = self.st.classify(source_input)
                row_mask   = golden_df["source_input"] == source_input
                human_lbl  = golden_df.loc[row_mask, "human_label"].iloc[0]

                similar_golden = self.st.get_similar_golden_samples(
                    source_input, golden_df.to_dict("records"), top_k=3
                )
                llm_result  = self.llm.judge(
                    source_input=source_input,
                    human_label=human_lbl,
                    st_label=predicted,
                    st_most_similar_kw=st_result.most_similar_keyword or "",
                    st_similarity_score=st_result.similarity_score,
                    similar_golden_samples=similar_golden,
                )
                llm_label   = llm_result["label"]
                llm_keyword = llm_result.get("generated_keyword", source_input)

                # Unclear during convergence: flag and skip
                if llm_label == "unclear":
                    logger.info(
                        "    LLM still unclear for '%s' — skipping this pass.",
                        source_input,
                    )
                    continue

                case = self._determine_case(human_lbl, predicted, llm_label)
                self._handle_keyword_update(case, llm_keyword, llm_label)

                golden_df.loc[row_mask, "llm_label"]        = llm_label
                golden_df.loc[row_mask, "llm_reasoning"]    = llm_result.get("reasoning", "")
                golden_df.loc[row_mask, "llm_generated_kw"] = llm_keyword
                golden_df.loc[row_mask, "case_type"]        = case.value
                golden_df.loc[row_mask, "final_label"]      = llm_label

            if self._kw_updates_since_refresh > 0:
                self.st.load_keyword_list(self._keyword_df)
                self._kw_updates_since_refresh = 0

        logger.warning(
            "Did not converge after %d passes. Final accuracy: %.1f%%",
            MAX_CONVERGENCE_PASSES,
            self.st.evaluate(golden_df)["accuracy"] * 100,
        )
        return golden_df, MAX_CONVERGENCE_PASSES
