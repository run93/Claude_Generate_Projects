"""
Mock GPT-OSS-120B model for development / testing.

Exposes a `.generate(prompt: str) -> str` interface identical to the
production server-based API. Responses are rule-based and cover all
pipeline branches including the "unclear" case.

Swap this with the real model object in production:

    from your_api_client import ServerModel
    model = ServerModel(endpoint="...", api_key="...")
    judge = LLMJudge(model)
"""

import json
import logging
import re

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lookup tables for the mock
# ---------------------------------------------------------------------------

# Terms the mock confidently classifies as HSHD
_HSHD_PATTERNS = [
    "ssn", "social security", "tax id", "tax identification",
    "national id", "national identification", "national insurance",
    "social insurance", "passport", "driver license", "driver's license",
    "date of birth", "dob", "bank account", "credit card",
    "medical record", "medicare", "biometric", "fingerprint",
    "face id", "facial", "dna", "resident registration",
    "alien number", "immigration", "government issued id",
    "government id", "birth certificate", "sin number",
    "nin ", "national insurance number",
]

# Terms the mock confidently classifies as Not HSHD
_NOT_HSHD_PATTERNS = [
    "product sku", "sku", "order number", "order reference",
    "invoice", "serial number", "tracking number", "transaction reference",
    "loyalty card", "loyalty points", "batch", "item code",
    "employee badge", "badge number", "social worker",
    "social media", "social network",
    "social club", "club membership",
]

# Terms the mock considers genuinely unclear — sent to human review
_UNCLEAR_PATTERNS = [
    "reference number",   # too generic; could be anything
    "voter registration", # HSHD in some jurisdictions, public record in others
    "club card",          # boundary between loyalty card and financial card unclear
]

# Canonical keyword suggestions for known inputs
_CANONICAL_KEYWORDS: dict[str, str] = {
    "ssn":                          "SSN",
    "passport number":              "Passport Number",
    "credit card no.":              "Credit Card Number",
    "tax id":                       "Tax ID",
    "social insurance number":      "Social Insurance Number",
    "national insurance number":    "National Insurance Number",
    "birth certificate":            "Birth Certificate",
    "social security card":         "Social Security Card",
    "employee badge number":        "Employee Badge Number",
    "social worker number":         "Social Worker Number",
    "social media account id":      "Social Media Account ID",
    "product sku":                  "Product SKU",
    "order reference number":       "Order Reference Number",
    "loyalty card number":          "Loyalty Card Number",
    "government issued id":         "Government Issued ID",
    "medicare number":              "Medicare Number",
    "resident registration number": "Resident Registration Number",
    "tracking number":              "Tracking Number",
    "fingerprint id":               "Fingerprint ID",
    "social club membership id":    "Social Club Membership ID",
    # Unclear samples — keyword is flagged for human review
    "reference number":             "Reference Number",
    "voter registration id":        "Voter Registration ID",
    "club card number":             "Club Card Number",
}

# Detailed reasoning strings
_REASONING: dict[str, str] = {
    # HSHD
    "tax id": (
        "Tax ID (Tax Identification Number) maps directly to SSN "
        "for US individuals and sole proprietors, making it HSHD."
    ),
    "social insurance number": (
        "Social Insurance Number (SIN) is Canada's equivalent of "
        "the US SSN — a government-issued personal identifier."
    ),
    "national insurance number": (
        "National Insurance Number (NIN) is the UK national "
        "identifier, equivalent to SSN — clearly HSHD."
    ),
    "birth certificate": (
        "A birth certificate number is an official government "
        "document uniquely tied to an individual's identity."
    ),
    "medicare number": (
        "Medicare number is a health-insurance identifier directly "
        "linked to an individual — HSHD."
    ),
    "resident registration number": (
        "Resident Registration Number is the Korean national ID "
        "equivalent — a government-issued personal identifier."
    ),
    "social security card": (
        "Social Security Card directly refers to the physical card "
        "bearing the SSN — this is HSHD; the human label appears incorrect."
    ),
    # Not HSHD
    "social worker number": (
        "Social Worker Number is an organisational role identifier, "
        "not a government-issued personal ID — Not HSHD."
    ),
    "social media account id": (
        "Social Media Account ID is a platform-specific handle, "
        "not a government or financial personal identifier — Not HSHD."
    ),
    "employee badge number": (
        "Employee Badge Number is an internal corporate identifier "
        "with no inherent personal sensitivity — Not HSHD. "
        "The human label appears to be incorrect."
    ),
    "social club membership id": (
        "Social Club Membership ID identifies membership in a club, "
        "not a natural person's sensitive data — Not HSHD."
    ),
    # Unclear
    "reference number": (
        "The term 'Reference Number' is too generic to classify confidently "
        "without additional business context. It could refer to an order "
        "reference (Not HSHD) or a case reference tied to a person (HSHD). "
        "Flagging for human review."
    ),
    "voter registration id": (
        "Voter Registration ID is a government-issued identifier, but its "
        "sensitivity varies by jurisdiction — in some regions it is a public "
        "record, in others it is protected. Cannot classify without knowing "
        "the applicable regulatory context. Flagging for human review."
    ),
    "club card number": (
        "Club Card Number could represent a loyalty card (Not HSHD) or a "
        "financial club card linked to a bank account (HSHD). The term alone "
        "is insufficient to determine sensitivity. Flagging for human review."
    ),
}


class MockLLMModel:
    """
    Simulates GPT-OSS-120B. The `.generate()` method parses the source_input
    from the prompt and applies a rule-based decision returning one of:
      HSHD | Not HSHD | unclear
    """

    def generate(self, prompt: str) -> str:
        source_input = self._extract_source_input(prompt)
        label        = self._classify(source_input)
        canonical    = _CANONICAL_KEYWORDS.get(source_input.lower(), source_input)
        reasoning    = self._get_reasoning(source_input, label)

        response = {
            "label":             label,
            "reasoning":         reasoning,
            "generated_keyword": canonical,
        }
        logger.debug("MockLLM '%s' -> %s", source_input, label)
        return json.dumps(response)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_source_input(prompt: str) -> str:
        """Pull the input term from the structured prompt."""
        match = re.search(r'"([^"]+)"\s*\n\n###\s*Available', prompt)
        if match:
            return match.group(1)
        match = re.search(r'"([^"]+)"', prompt)
        return match.group(1) if match else ""

    @staticmethod
    def _classify(text: str) -> str:
        lower = text.lower()
        # Check unclear patterns first (most specific override)
        for pat in _UNCLEAR_PATTERNS:
            if pat in lower:
                return "unclear"
        # Then Not HSHD (overrides generic HSHD patterns for known FPs)
        for pat in _NOT_HSHD_PATTERNS:
            if pat in lower:
                return "Not HSHD"
        for pat in _HSHD_PATTERNS:
            if pat in lower:
                return "HSHD"
        return "Not HSHD"

    @staticmethod
    def _get_reasoning(text: str, label: str) -> str:
        lower = text.lower()
        # Check exact-match reasoning first
        for key, reason in _REASONING.items():
            if key in lower:
                return reason
        # Generic fallbacks
        if label == "HSHD":
            return f'"{text}" is a personal identifier that qualifies as HSHD.'
        if label == "Not HSHD":
            return f'"{text}" does not constitute personally sensitive data — Not HSHD.'
        return (
            f'"{text}" is ambiguous without additional context. '
            "Flagging for human review."
        )
