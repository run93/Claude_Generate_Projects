"""
LLM-based judge that arbitrates between the human label and the sentence-
transformer prediction.

The judge receives:
  - source_input        : the keyword/phrase being classified
  - human_label         : label from the silver dataset ("HSHD" / "Not HSHD")
  - st_label            : sentence-transformer prediction
  - st_most_similar_kw  : the keyword with the highest cosine similarity
  - st_similarity_score : that cosine similarity score
  - similar_golden      : list of already-curated golden-dataset samples to
                          give the LLM few-shot context

The judge returns a dict:
  {
    "label"             : "HSHD" | "Not HSHD" | "unclear",
    "reasoning"         : str,
    "generated_keyword" : str   # canonical keyword to add to the keyword list
  }

  When label == "unclear":
    - The sample is written to unknown_silver_dataset.csv for human review.
    - The generated_keyword is written to unclear_keywords.csv.
    - The sample is NOT added to the golden dataset.
    - The keyword list is NOT updated.

The model object must expose a `.generate(prompt: str) -> str` method
(matching the GPT-OSS-120B server-based API contract).
"""

import json
import logging
import re

logger = logging.getLogger(__name__)

_VALID_LABELS = {"HSHD", "Not HSHD", "unclear"}

_SYSTEM_PROMPT = """You are a data-privacy expert who classifies whether a term \
represents Highly Sensitive Human Data (HSHD).

HSHD: personal information that can uniquely identify or reveal sensitive details \
about an individual. Examples:
  - Government-issued IDs (SSN, Passport, Driver License, National ID, SIN, NIN)
  - Tax identification numbers that map to SSN (Tax ID, EIN for sole proprietors)
  - Financial account identifiers (Bank Account Number, Credit Card Number)
  - Biometric identifiers (Fingerprint, Face ID, DNA)
  - Health / medical identifiers (Medical Record Number, Medicare Number)
  - Immigration / residency IDs (Resident Registration Number, Alien Number)
  - Date of Birth when used alone as an identifier

NOT HSHD: identifiers that do not map to a natural person's sensitive data. Examples:
  - Product / inventory codes (SKU, Product ID, Serial Number)
  - Order / logistics codes (Order Number, Tracking Number, Invoice Number)
  - Internal system references (Transaction Reference, Batch ID)
  - Membership / loyalty codes that carry no personal identity information
  - Organisational role codes (Employee Badge Number, Social Worker ID)
  - Social-media account identifiers (not tied to government identity)

UNCLEAR: use this label when the term is genuinely ambiguous and you cannot make
a confident determination with the available signals. Examples of when to use:
  - The term is too generic to infer a specific data type (e.g. "Reference Number")
  - The classification differs significantly across jurisdictions or contexts
  - The human label and ST signals strongly contradict each other with no resolution
  - You would need additional business-context to decide safely

When a term is ambiguous but you can decide, apply: "could a bad actor use this
term alone to find or harm a specific real person?" If yes → HSHD. If no → Not HSHD.
Reserve "unclear" only for cases where even this rule cannot resolve the ambiguity.
"""

_USER_PROMPT_TEMPLATE = """\
## Task
Decide whether the following input is HSHD, Not HSHD, or unclear.

### Input
"{source_input}"

### Available signals
| Signal | Value |
|--------|-------|
| Human label | {human_label} |
| Sentence-transformer closest keyword | "{st_most_similar_kw}" |
| Cosine similarity | {st_similarity_score:.4f} |
| Sentence-transformer prediction | {st_label} |

### Context: similar curated samples
{similar_samples_block}

### Instructions
1. Consider all signals. The human label may be wrong. The sentence-transformer
   may be wrong. Use your domain expertise to decide.
2. If genuinely ambiguous after applying all signals, set label to "unclear".
3. Produce a single canonical keyword that best represents this concept for the
   purpose of updating (or flagging) the keyword list.
4. Respond with **only** a JSON object matching this schema — no markdown fences:

{{
  "label": "<HSHD|Not HSHD|unclear>",
  "reasoning": "<one or two sentences explaining your decision or the ambiguity>",
  "generated_keyword": "<canonical keyword string>"
}}
"""


class LLMJudge:
    def __init__(self, model):
        """
        Parameters
        ----------
        model : Any
            Object with a `.generate(prompt: str) -> str` method.
            In production this wraps the GPT-OSS-120B server API.
        """
        self.model = model

    def judge(
        self,
        source_input: str,
        human_label: str,
        st_label: str,
        st_most_similar_kw: str,
        st_similarity_score: float,
        similar_golden_samples: list[dict],
    ) -> dict:
        """
        Call the LLM to produce a final judgment.

        Returns
        -------
        dict with keys:
          label             : "HSHD" | "Not HSHD" | "unclear"
          reasoning         : str
          generated_keyword : str
        """
        similar_block = self._format_similar_samples(similar_golden_samples)

        full_prompt = (
            _SYSTEM_PROMPT
            + "\n\n"
            + _USER_PROMPT_TEMPLATE.format(
                source_input=source_input,
                human_label=human_label,
                st_most_similar_kw=st_most_similar_kw or "N/A",
                st_similarity_score=st_similarity_score,
                st_label=st_label,
                similar_samples_block=similar_block,
            )
        )

        logger.debug("LLM prompt for '%s':\n%s", source_input, full_prompt)
        raw_response = self.model.generate(full_prompt)
        logger.debug("LLM raw response: %s", raw_response)

        return self._parse_response(raw_response, source_input)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _format_similar_samples(samples: list[dict]) -> str:
        if not samples:
            return "(none yet)"
        lines = []
        for s in samples:
            lines.append(
                f'- "{s["source_input"]}" -> **{s["final_label"]}** '
                f'(human: {s["human_label"]})'
            )
        return "\n".join(lines)

    @staticmethod
    def _parse_response(raw: str, source_input: str) -> dict:
        """
        Extract JSON from the LLM response.

        Valid labels: "HSHD", "Not HSHD", "unclear".
        Falls back to "unclear" (not "Not HSHD") when parsing fails, so that
        borderline samples go to human review rather than being silently
        classified incorrectly.
        """
        cleaned = re.sub(r"```(?:json)?", "", raw).strip()

        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            try:
                result = json.loads(match.group())
                raw_label = str(result.get("label", "")).strip()

                # Normalise label
                if raw_label.upper() == "HSHD":
                    result["label"] = "HSHD"
                elif raw_label.lower() in ("not hshd", "nothshd", "not_hshd"):
                    result["label"] = "Not HSHD"
                elif raw_label.lower() == "unclear":
                    result["label"] = "unclear"
                else:
                    logger.warning(
                        "Unrecognised label '%s' for '%s' — marking unclear.",
                        raw_label, source_input,
                    )
                    result["label"] = "unclear"

                result.setdefault("reasoning", "")
                result.setdefault("generated_keyword", source_input)
                return result

            except json.JSONDecodeError as exc:
                logger.warning("JSON parse failed: %s — raw: %s", exc, raw)

        logger.error(
            "Could not parse LLM response for '%s'. Marking as unclear for human review.",
            source_input,
        )
        return {
            "label": "unclear",
            "reasoning": "LLM response could not be parsed — flagged for human review.",
            "generated_keyword": source_input,
        }
