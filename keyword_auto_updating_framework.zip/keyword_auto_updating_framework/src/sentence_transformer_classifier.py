"""
Sentence-Transformer classifier using bge-m3.

Classifies whether a source_input is HSHD or Not HSHD by computing cosine
similarity against a labeled keyword list. The keyword that has the highest
similarity score determines the label when that score exceeds the threshold.

Tie-breaking: if the best-matching HSHD keyword and the best-matching Not HSHD
keyword have the same top score (within floating-point), HSHD wins (conservative).
"""

import logging
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger(__name__)


@dataclass
class ClassificationResult:
    label: str                          # "HSHD" or "Not HSHD"
    most_similar_keyword: Optional[str]
    similarity_score: float
    best_hshd_keyword: Optional[str]
    best_hshd_score: float
    best_not_hshd_keyword: Optional[str]
    best_not_hshd_score: float


@dataclass
class _KeywordEntry:
    keyword: str
    label: str
    embedding: np.ndarray


class SentenceTransformerClassifier:
    """
    Wraps bge-m3 and a mutable keyword list to classify arbitrary text as
    HSHD or Not HSHD.

    Classification logic
    --------------------
    1. Find the best-matching HSHD keyword  (score_hshd, kw_hshd)
    2. Find the best-matching Not-HSHD keyword (score_not, kw_not)
    3. If score_hshd >= threshold AND score_hshd >= score_not  → HSHD
       Else                                                     → Not HSHD

    This means adding a Not-HSHD keyword that is *more* similar to a false-
    positive input than any HSHD keyword will flip the prediction — directly
    supporting the FP-correction workflow.
    """

    def __init__(self, model_name: str = "BAAI/bge-m3", threshold: float = 0.70):
        logger.info("Loading sentence-transformer model: %s", model_name)
        self.model = SentenceTransformer(model_name)
        self.threshold = threshold
        self._entries: list[_KeywordEntry] = []
        # Cache for golden-dataset sample embeddings (keyed by source_input)
        self._golden_cache: dict[str, np.ndarray] = {}

    # ------------------------------------------------------------------
    # Keyword list management
    # ------------------------------------------------------------------

    def load_keyword_list(self, keyword_df: pd.DataFrame) -> None:
        """
        (Re-)embed the full keyword list. Call this once at startup and again
        whenever the keyword list has grown enough to warrant a refresh.
        """
        logger.info("Encoding %d keywords …", len(keyword_df))
        self._entries = []
        for _, row in keyword_df.iterrows():
            emb = self._encode(str(row["keyword"]))
            self._entries.append(
                _KeywordEntry(
                    keyword=str(row["keyword"]),
                    label=str(row["label"]),
                    embedding=emb,
                )
            )
        logger.info("Keyword list loaded (%d entries).", len(self._entries))

    # ------------------------------------------------------------------
    # Classification
    # ------------------------------------------------------------------

    def classify(self, text: str) -> ClassificationResult:
        """Return a ClassificationResult for the given text."""
        if not self._entries:
            return ClassificationResult(
                label="Not HSHD",
                most_similar_keyword=None,
                similarity_score=0.0,
                best_hshd_keyword=None,
                best_hshd_score=0.0,
                best_not_hshd_keyword=None,
                best_not_hshd_score=0.0,
            )

        text_emb = self._encode(text)

        best_hshd_score, best_hshd_kw = -1.0, None
        best_not_score, best_not_kw = -1.0, None
        overall_best_score, overall_best_kw = -1.0, None

        for entry in self._entries:
            score = float(
                cosine_similarity([text_emb], [entry.embedding])[0][0]
            )
            if score > overall_best_score:
                overall_best_score = score
                overall_best_kw = entry.keyword

            if entry.label == "HSHD":
                if score > best_hshd_score:
                    best_hshd_score = score
                    best_hshd_kw = entry.keyword
            else:
                if score > best_not_score:
                    best_not_score = score
                    best_not_kw = entry.keyword

        # Decision rule
        if best_hshd_score >= self.threshold and best_hshd_score >= best_not_score:
            label = "HSHD"
        else:
            label = "Not HSHD"

        return ClassificationResult(
            label=label,
            most_similar_keyword=overall_best_kw,
            similarity_score=round(overall_best_score, 4),
            best_hshd_keyword=best_hshd_kw,
            best_hshd_score=round(best_hshd_score, 4),
            best_not_hshd_keyword=best_not_kw,
            best_not_hshd_score=round(best_not_score, 4),
        )

    # ------------------------------------------------------------------
    # Golden-dataset context retrieval
    # ------------------------------------------------------------------

    def get_similar_golden_samples(
        self,
        text: str,
        golden_samples: list[dict],
        top_k: int = 3,
    ) -> list[dict]:
        """
        Return the top-k most similar samples from the current golden dataset,
        used to give the LLM judge few-shot context.
        """
        if not golden_samples:
            return []

        text_emb = self._encode(text)
        scored = []
        for sample in golden_samples:
            key = sample["source_input"]
            if key not in self._golden_cache:
                self._golden_cache[key] = self._encode(key)
            sim = float(
                cosine_similarity([text_emb], [self._golden_cache[key]])[0][0]
            )
            scored.append((sim, sample))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [s for _, s in scored[:top_k]]

    def invalidate_golden_cache(self) -> None:
        """Call after clearing / rebuilding the golden dataset."""
        self._golden_cache.clear()

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(self, golden_df: pd.DataFrame) -> dict:
        """
        Compute accuracy of the current keyword list + threshold against the
        golden dataset's final_label column.
        """
        correct = 0
        errors = []
        for _, row in golden_df.iterrows():
            result = self.classify(str(row["source_input"]))
            if result.label == row["final_label"]:
                correct += 1
            else:
                errors.append(
                    {
                        "source_input": row["source_input"],
                        "expected": row["final_label"],
                        "predicted": result.label,
                        "best_hshd_kw": result.best_hshd_keyword,
                        "best_hshd_score": result.best_hshd_score,
                        "best_not_hshd_kw": result.best_not_hshd_keyword,
                        "best_not_hshd_score": result.best_not_hshd_score,
                    }
                )
        accuracy = correct / len(golden_df) if len(golden_df) > 0 else 0.0
        return {"accuracy": accuracy, "errors": errors, "total": len(golden_df)}

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _encode(self, text: str) -> np.ndarray:
        return self.model.encode(text, normalize_embeddings=True)
