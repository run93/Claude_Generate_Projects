"""
main.py — entry point for the keyword auto-updating golden-dataset curation framework.

Usage
-----
    python main.py

Outputs (written to ./output/)
  golden_dataset.csv        LLM-curated golden dataset
  final_keyword_list.csv    updated keyword list (initial + LLM-generated)
  unknown_silver_dataset.csv  samples the LLM could not confidently classify
  unclear_keywords.csv      keywords flagged by LLM for human review
  pipeline_summary.txt      human-readable run summary

To use the real GPT-OSS-120B model, replace MockLLMModel with your server client:

    from your_api_client import ServerModel
    model = ServerModel(endpoint="...", api_key="...")
    judge = LLMJudge(model=model)
"""

import logging
import sys
from pathlib import Path

import pandas as pd

from src.sentence_transformer_classifier import SentenceTransformerClassifier
from src.llm_judge import LLMJudge
from src.mock_llm import MockLLMModel
from src.pipeline import Pipeline, PipelineResult

# ── logging ────────────────────────────────────────────────────────────────────
OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(OUTPUT_DIR / "run.log", mode="w", encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)

DATA_DIR = Path("data")


# ── helpers ────────────────────────────────────────────────────────────────────

def load_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    keyword_df = pd.read_csv(DATA_DIR / "initial_keyword_list.csv")
    silver_df  = pd.read_csv(DATA_DIR / "silver_dataset.csv")
    logger.info(
        "Loaded %d keywords and %d silver-dataset samples.",
        len(keyword_df), len(silver_df),
    )
    return keyword_df, silver_df


def build_pipeline() -> Pipeline:
    st_classifier = SentenceTransformerClassifier(
        model_name="BAAI/bge-m3",
        threshold=0.70,
    )
    llm_model = MockLLMModel()   # <- swap for real model here
    llm_judge = LLMJudge(model=llm_model)
    return Pipeline(st_classifier=st_classifier, llm_judge=llm_judge)


def save_outputs(result: PipelineResult) -> None:
    paths = {
        "golden_dataset":         OUTPUT_DIR / "golden_dataset.csv",
        "final_keyword_list":     OUTPUT_DIR / "final_keyword_list.csv",
        "unknown_silver_dataset": OUTPUT_DIR / "unknown_silver_dataset.csv",
        "unclear_keywords":       OUTPUT_DIR / "unclear_keywords.csv",
    }

    result.golden_df.to_csv(paths["golden_dataset"],         index=False)
    result.keyword_df.to_csv(paths["final_keyword_list"],    index=False)
    result.unknown_silver_df.to_csv(paths["unknown_silver_dataset"], index=False)
    result.unclear_keywords_df.to_csv(paths["unclear_keywords"],     index=False)

    for name, path in paths.items():
        logger.info("%-26s -> %s", name, path)

    _write_summary(result)


def _write_summary(result: PipelineResult) -> None:
    case_counts  = result.golden_df["case_type"].value_counts().to_dict()
    new_keywords = result.keyword_df[result.keyword_df["source"] == "LLM_generated"]

    lines = [
        "=" * 60,
        "PIPELINE SUMMARY",
        "=" * 60,
        f"Golden dataset samples : {len(result.golden_df)}",
        f"Unknown (unclear) samples: {len(result.unknown_silver_df)}",
        f"Final ST accuracy      : {result.final_accuracy * 100:.1f}%",
        f"Convergence passes     : {result.convergence_passes}",
        "",
        "Case breakdown (golden dataset):",
        *[f"  {k:<30} {v}" for k, v in sorted(case_counts.items())],
        "",
        f"New LLM-generated keywords ({len(new_keywords)}):",
        *[f"  [{row['label']:<10}] {row['keyword']}" for _, row in new_keywords.iterrows()],
        "",
        f"Unclear keywords flagged for review ({len(result.unclear_keywords_df)}):",
        *[f"  {row['keyword']}" for _, row in result.unclear_keywords_df.iterrows()],
        "",
        "Label distribution (golden dataset):",
        *[f"  {lbl:<15} {cnt}"
          for lbl, cnt in result.golden_df["final_label"].value_counts().items()],
        "=" * 60,
    ]

    summary_text = "\n".join(lines)
    summary_path = OUTPUT_DIR / "pipeline_summary.txt"
    summary_path.write_text(summary_text, encoding="utf-8")
    logger.info("\n%s", summary_text)


# ── entry point ────────────────────────────────────────────────────────────────

def main() -> None:
    logger.info("Starting keyword auto-updating framework.")

    keyword_df, silver_df = load_data()
    pipeline = build_pipeline()
    result   = pipeline.run(silver_df=silver_df, keyword_df=keyword_df)

    save_outputs(result)

    if result.final_accuracy < 1.0:
        logger.warning(
            "Pipeline did not fully converge. "
            "Consider reviewing unclear samples and adding keywords manually."
        )
        sys.exit(1)

    logger.info("Done.")


if __name__ == "__main__":
    main()
