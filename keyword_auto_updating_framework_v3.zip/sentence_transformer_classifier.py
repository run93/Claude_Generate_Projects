"""
Sentence-Transformer classifier using bge-m3.

Key design points
-----------------
* All keyword embeddings are stacked into a matrix on load_keyword_list() so
  every classify / classify_batch call does one fast matrix multiply instead of
  a per-entry loop.
* classify_batch() encodes all inputs in one batched forward pass (parallel),
  then scores against the keyword matrix — suitable for pre-screening the whole
  silver dataset before the LLM pass.
* classify_batch_from_embeddings() accepts a pre-computed (M, D) numpy array
  (loaded from a pickle file) and skips the expensive model.encode() step
  entirely — this is the fast path for large silver datasets.
* Classification rule:
    1. Find best-matching HSHD keyword    (score_hshd, kw_hshd)
    2. Find best-matching Not-HSHD keyword (score_not,  kw_not)
    3. If score_hshd >= threshold AND score_hshd >= score_not → HSHD
       Else                                                    → Not HSHD
  This means adding a Not-HSHD keyword that outscores existing HSHD keywords
  for a false-positive input will flip its prediction — directly supporting
  the FP-correction workflow.

Pre-computed embedding pickle format
-------------------------------------
The pickle file must contain either:
  (a) numpy.ndarray  of shape (N, D)          — plain embedding matrix
  (b) dict with keys:
        "embeddings" : numpy.ndarray (N, D)   — embedding matrix
        "texts"      : list[str]   (N,)       — optional; used to validate
                                                 row order against silver_df
Both must be L2-normalised (normalise_embeddings=True) to ensure cosine
similarity is computed correctly.  The helper save_silver_embeddings() writes
this format automatically.
"""

import logging
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger(__name__)


@dataclass
class ClassificationResult:
    label: str                              # "HSHD" or "Not HSHD"
    most_similar_keyword: Optional[str]
    similarity_score: float
    best_hshd_keyword: Optional[str]
    best_hshd_score: float
    best_not_hshd_keyword: Optional[str]
    best_not_hshd_score: float


@dataclass
class _KeywordEntry:
    keyword: str
    label:   str
    embedding: np.ndarray


class SentenceTransformerClassifier:
    def __init__(self, model_name: str = "BAAI/bge-m3", threshold: float = 0.70):
        logger.info("Loading sentence-transformer model: %s", model_name)
        self.model     = SentenceTransformer(model_name)
        self.threshold = threshold

        self._entries:    list[_KeywordEntry] = []
        self._kw_matrix:  Optional[np.ndarray] = None   # shape (N, D)
        self._golden_cache: dict[str, np.ndarray] = {}

    # ------------------------------------------------------------------
    # Keyword list management
    # ------------------------------------------------------------------

    def load_keyword_list(self, keyword_df: pd.DataFrame) -> None:
        """
        (Re-)embed the full keyword list and rebuild the similarity matrix.
        Call at startup and after every KEYWORD_UPDATE_INTERVAL additions.
        """
        logger.info("Encoding %d keywords …", len(keyword_df))
        texts = keyword_df["keyword"].astype(str).tolist()
        embs  = self.model.encode(
            texts,
            normalize_embeddings=True,
            batch_size=64,
            show_progress_bar=False,
        )

        self._entries = [
            _KeywordEntry(
                keyword=str(row["keyword"]),
                label=str(row["label"]),
                embedding=embs[i],
            )
            for i, (_, row) in enumerate(keyword_df.iterrows())
        ]
        # Pre-stack for fast matrix multiply
        self._kw_matrix = np.vstack([e.embedding for e in self._entries])
        logger.info("Keyword matrix ready: %s", self._kw_matrix.shape)

    # ------------------------------------------------------------------
    # Classification — single
    # ------------------------------------------------------------------

    def classify(self, text: str) -> ClassificationResult:
        emb = self._encode_single(text)
        return self._classify_from_embedding(emb)

    # ------------------------------------------------------------------
    # Classification — batch (parallel encode, then matrix score)
    # ------------------------------------------------------------------

    def classify_batch(
        self,
        texts: list[str],
        batch_size: int = 64,
        show_progress_bar: bool = True,
    ) -> list[ClassificationResult]:
        """
        Encode ALL texts in a single batched forward pass, then compute
        cosine similarities against the keyword matrix in one shot.
        Returns a list of ClassificationResult in the same order as texts.
        """
        if not self._entries or self._kw_matrix is None:
            logger.warning("classify_batch called before load_keyword_list.")
            return [
                ClassificationResult(
                    label="Not HSHD",
                    most_similar_keyword=None,
                    similarity_score=0.0,
                    best_hshd_keyword=None,
                    best_hshd_score=0.0,
                    best_not_hshd_keyword=None,
                    best_not_hshd_score=0.0,
                )
                for _ in texts
            ]

        logger.info(
            "Batch-encoding %d inputs (batch_size=%d) …", len(texts), batch_size
        )
        text_embs = self.model.encode(
            texts,
            normalize_embeddings=True,
            batch_size=batch_size,
            show_progress_bar=show_progress_bar,
        )
        # Delegate to shared scoring helper
        return self._score_against_keyword_matrix(text_embs)

    # ------------------------------------------------------------------
    # Classification — fast path using pre-computed embeddings
    # ------------------------------------------------------------------

    def classify_batch_from_embeddings(
        self,
        text_embs: np.ndarray,
    ) -> list[ClassificationResult]:
        """
        Score a pre-computed (M, D) embedding matrix against the keyword
        matrix without calling model.encode() at all.

        This is the fast path for large silver datasets when the embeddings
        have already been computed and saved to a pickle file.

        Parameters
        ----------
        text_embs : np.ndarray, shape (M, D)
            L2-normalised embeddings in the same row order as the silver_df
            that was used to generate them.

        Returns
        -------
        list[ClassificationResult]  length M, same row order as text_embs.
        """
        if not self._entries or self._kw_matrix is None:
            raise RuntimeError("Call load_keyword_list() before classify_batch_from_embeddings().")

        if text_embs.ndim != 2:
            raise ValueError(
                f"Expected 2-D embedding matrix (M, D), got shape {text_embs.shape}."
            )

        expected_dim = self._kw_matrix.shape[1]
        if text_embs.shape[1] != expected_dim:
            raise ValueError(
                f"Embedding dimension mismatch: silver embeddings have dim "
                f"{text_embs.shape[1]}, keyword matrix has dim {expected_dim}. "
                "Were both generated with the same model?"
            )

        logger.info(
            "Scoring %d pre-computed embeddings (dim=%d) against keyword matrix …",
            text_embs.shape[0], text_embs.shape[1],
        )
        # Reuse the shared scoring logic — identical to classify_batch()
        return self._score_against_keyword_matrix(text_embs)

    # ------------------------------------------------------------------
    # Helpers: save / load silver embeddings
    # ------------------------------------------------------------------

    def encode_and_save_silver_embeddings(
        self,
        silver_df: pd.DataFrame,
        pkl_path: Union[str, Path],
        text_col: str = "source_input",
        batch_size: int = 64,
    ) -> np.ndarray:
        """
        Encode silver_df[text_col], save to pickle, and return the matrix.

        Pickle format (dict):
            {
                "embeddings": np.ndarray  (N, D),   L2-normalised
                "texts":      list[str]   (N,)       for order validation
            }

        Use this once to generate the pkl file; subsequent runs can skip
        encoding by loading the pkl directly.

        Example
        -------
        >>> embs = st.encode_and_save_silver_embeddings(
        ...     silver_df, "data/silver_embeddings.pkl"
        ... )
        """
        texts = silver_df[text_col].astype(str).tolist()
        logger.info(
            "Encoding %d silver-dataset inputs (batch_size=%d) for caching …",
            len(texts), batch_size,
        )
        embs = self.model.encode(
            texts,
            normalize_embeddings=True,
            batch_size=batch_size,
            show_progress_bar=True,
        )
        payload = {"embeddings": embs, "texts": texts}
        pkl_path = Path(pkl_path)
        pkl_path.parent.mkdir(parents=True, exist_ok=True)
        with open(pkl_path, "wb") as fh:
            pickle.dump(payload, fh, protocol=pickle.HIGHEST_PROTOCOL)
        logger.info("Silver embeddings saved to %s  (shape %s)", pkl_path, embs.shape)
        return embs

    @staticmethod
    def load_silver_embeddings(
        pkl_path: Union[str, Path],
        silver_df: Optional[pd.DataFrame] = None,
        text_col: str = "source_input",
    ) -> np.ndarray:
        """
        Load pre-computed silver embeddings from a pickle file.

        Accepts either of the two supported formats:
            (a) numpy.ndarray  shape (N, D)
            (b) dict { "embeddings": ndarray, "texts": list[str] (optional) }

        If silver_df is provided and the pickle contains a "texts" key,
        the row order is validated against silver_df[text_col] and a clear
        error is raised on mismatch.

        Returns
        -------
        np.ndarray  shape (N, D), L2-normalised.
        """
        pkl_path = Path(pkl_path)
        if not pkl_path.exists():
            raise FileNotFoundError(
                f"Silver embeddings pickle not found: {pkl_path}\n"
                "Run st_classifier.encode_and_save_silver_embeddings() first."
            )

        with open(pkl_path, "rb") as fh:
            payload = pickle.load(fh)

        # ── Format (a): bare numpy array ─────────────────────────────
        if isinstance(payload, np.ndarray):
            embs = payload

        # ── Format (b): dict with "embeddings" key ───────────────────
        elif isinstance(payload, dict):
            if "embeddings" not in payload:
                raise KeyError(
                    "Pickle dict must contain an 'embeddings' key (np.ndarray)."
                )
            embs = payload["embeddings"]

            # Optional row-order validation
            if silver_df is not None and "texts" in payload:
                expected = silver_df[text_col].astype(str).tolist()
                stored   = payload["texts"]
                if len(stored) != len(expected):
                    raise ValueError(
                        f"Row count mismatch: pickle has {len(stored)} rows, "
                        f"silver_df has {len(expected)} rows."
                    )
                mismatches = [
                    (i, s, e)
                    for i, (s, e) in enumerate(zip(stored, expected))
                    if s != e
                ]
                if mismatches:
                    sample = mismatches[:3]
                    raise ValueError(
                        f"Row order mismatch between pickle texts and silver_df "
                        f"(first {len(sample)} diffs): {sample}\n"
                        "Re-generate the pickle with encode_and_save_silver_embeddings()."
                    )
                logger.info("Pickle row order validated against silver_df (%d rows).", len(expected))

        else:
            raise TypeError(
                f"Unsupported pickle format: {type(payload)}. "
                "Expected numpy.ndarray or dict."
            )

        if embs.ndim != 2:
            raise ValueError(f"Expected 2-D embedding matrix, got shape {embs.shape}.")

        logger.info("Loaded silver embeddings from %s  (shape %s)", pkl_path, embs.shape)
        return embs

    # ------------------------------------------------------------------
    # Golden-dataset context retrieval
    # ------------------------------------------------------------------

    def get_similar_golden_samples(
        self,
        text: str,
        golden_samples: list[dict],
        top_k: int = 3,
    ) -> list[dict]:
        if not golden_samples:
            return []

        text_emb = self._encode_single(text)
        scored   = []
        for sample in golden_samples:
            key = sample["source_input"]
            if key not in self._golden_cache:
                self._golden_cache[key] = self._encode_single(key)
            sim = float(
                cosine_similarity([text_emb], [self._golden_cache[key]])[0][0]
            )
            scored.append((sim, sample))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [s for _, s in scored[:top_k]]

    def invalidate_golden_cache(self) -> None:
        self._golden_cache.clear()

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(self, golden_df: pd.DataFrame) -> dict:
        """
        Batch-classify all golden samples and report accuracy + error list.
        """
        if golden_df.empty:
            return {"accuracy": 1.0, "errors": [], "total": 0}

        texts   = golden_df["source_input"].astype(str).tolist()
        labels  = golden_df["final_label"].tolist()
        results = self.classify_batch(texts, show_progress_bar=False)

        correct = 0
        errors  = []
        for r, expected, text in zip(results, labels, texts):
            if r.label == expected:
                correct += 1
            else:
                errors.append({
                    "source_input":       text,
                    "expected":           expected,
                    "predicted":          r.label,
                    "best_hshd_kw":       r.best_hshd_keyword,
                    "best_hshd_score":    r.best_hshd_score,
                    "best_not_hshd_kw":   r.best_not_hshd_keyword,
                    "best_not_hshd_score":r.best_not_hshd_score,
                })

        accuracy = correct / len(golden_df)
        return {"accuracy": accuracy, "errors": errors, "total": len(golden_df)}

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _classify_from_embedding(self, text_emb: np.ndarray) -> ClassificationResult:
        if not self._entries or self._kw_matrix is None:
            return ClassificationResult(
                label="Not HSHD",
                most_similar_keyword=None,
                similarity_score=0.0,
                best_hshd_keyword=None,
                best_hshd_score=0.0,
                best_not_hshd_keyword=None,
                best_not_hshd_score=0.0,
            )

        scores = cosine_similarity([text_emb], self._kw_matrix)[0]

        overall_best_idx   = int(np.argmax(scores))
        overall_best_score = float(scores[overall_best_idx])

        best_hshd_score, best_hshd_idx = -1.0, -1
        best_not_score,  best_not_idx  = -1.0, -1

        for i, entry in enumerate(self._entries):
            s = float(scores[i])
            if entry.label == "HSHD" and s > best_hshd_score:
                best_hshd_score, best_hshd_idx = s, i
            elif entry.label == "Not HSHD" and s > best_not_score:
                best_not_score, best_not_idx = s, i

        if best_hshd_score >= self.threshold and best_hshd_score >= best_not_score:
            label = "HSHD"
        else:
            label = "Not HSHD"

        return ClassificationResult(
            label=label,
            most_similar_keyword=self._entries[overall_best_idx].keyword,
            similarity_score=round(overall_best_score, 4),
            best_hshd_keyword=self._entries[best_hshd_idx].keyword if best_hshd_idx >= 0 else None,
            best_hshd_score=round(best_hshd_score, 4),
            best_not_hshd_keyword=self._entries[best_not_idx].keyword if best_not_idx >= 0 else None,
            best_not_hshd_score=round(best_not_score, 4),
        )

    def _score_against_keyword_matrix(
        self, text_embs: np.ndarray
    ) -> list[ClassificationResult]:
        """
        Shared inner loop used by both classify_batch() and
        classify_batch_from_embeddings().

        text_embs : np.ndarray  (M, D)  — L2-normalised input embeddings
        Returns   : list[ClassificationResult]  length M
        """
        # (M, N) similarity matrix — one matmul for the whole batch
        sim_matrix    = cosine_similarity(text_embs, self._kw_matrix)
        hshd_mask     = np.array([e.label == "HSHD"     for e in self._entries])
        not_hshd_mask = np.array([e.label == "Not HSHD" for e in self._entries])

        results = []
        for scores in sim_matrix:
            overall_best_idx   = int(np.argmax(scores))
            overall_best_score = float(scores[overall_best_idx])

            # Mask away opposite-class scores so argmax picks within-class best
            hshd_scores = np.where(hshd_mask,     scores, -np.inf)
            not_scores  = np.where(not_hshd_mask, scores, -np.inf)

            best_hshd_idx   = int(np.argmax(hshd_scores))
            best_not_idx    = int(np.argmax(not_scores))
            best_hshd_score = float(scores[best_hshd_idx]) if hshd_mask.any()     else -1.0
            best_not_score  = float(scores[best_not_idx])  if not_hshd_mask.any() else -1.0

            label = (
                "HSHD"
                if best_hshd_score >= self.threshold and best_hshd_score >= best_not_score
                else "Not HSHD"
            )

            results.append(ClassificationResult(
                label=label,
                most_similar_keyword=self._entries[overall_best_idx].keyword,
                similarity_score=round(overall_best_score, 4),
                best_hshd_keyword=(
                    self._entries[best_hshd_idx].keyword if hshd_mask.any() else None
                ),
                best_hshd_score=round(best_hshd_score, 4),
                best_not_hshd_keyword=(
                    self._entries[best_not_idx].keyword if not_hshd_mask.any() else None
                ),
                best_not_hshd_score=round(best_not_score, 4),
            ))
        return results

    def _encode_single(self, text: str) -> np.ndarray:
        return self.model.encode(text, normalize_embeddings=True)
