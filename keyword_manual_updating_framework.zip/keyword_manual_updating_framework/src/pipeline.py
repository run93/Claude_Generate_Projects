"""
Golden-dataset curation pipeline.

Execution flow
==============

PHASE 1 — Batch ST pre-screen  (parallel, no LLM)
--------------------------------------------------
1a. If pre-computed silver embeddings are supplied (pkl path or ndarray), load
    them and skip model.encode() entirely — fast path for large silver datasets.
1b. Otherwise run the ST model on ALL silver-dataset samples in one batched
    forward pass — standard path.
2. Separate into two buckets:
     MATCH    : human_label == ST label  → add directly to golden dataset
     MISMATCH : human_label != ST label  → queue for LLM arbitration
3. Print progress banner:
     "New Iteration: N samples  |  M (xx%) Match  |  X (xx%) Not Match"

PHASE 2 — LLM arbitration  (mismatches only)
--------------------------------------------
4. For each mismatch (with [i/total] progress):
     a. Retrieve similar golden samples for LLM context.
     b. Call LLM judge.
     c. If LLM → "unclear": write to unknown_silver + unclear_keywords; skip.
     d. Else: determine case, update keyword list (add BOTH original input AND
              generated keyword), add to golden.
5. Every CHECKPOINT_INTERVAL keyword additions:
     - Refresh ST keyword matrix embeddings.
     - Save all 4 output files to disk (real-time checkpoint).

PHASE 3 — Convergence loop
--------------------------
6. Re-run batch ST on the current golden dataset.
7. Identify any ST predictions that still differ from final_label.
8. LLM-arbitrate the remaining errors, updating keywords as needed.
9. Repeat until 100 % accuracy or MAX_CONVERGENCE_PASSES reached.
   Checkpoint after every pass.

Keyword-list update rules (Case taxonomy)
-----------------------------------------
Case 3  ST_FALSE_NEGATIVE  LLM=HSHD / human=HSHD / ST=Not HSHD
        → add HSHD entries: original input  +  LLM canonical keyword
Case 4  WRONG_LABEL_FP     LLM=HSHD / human=Not HSHD / ST=HSHD
        → no keyword change (ST was correct; only the human label was wrong)
Case 5  ST_FALSE_POSITIVE  LLM=Not HSHD / human=Not HSHD / ST=HSHD
        → add Not HSHD entries: original input  +  LLM canonical keyword
Case 6  WRONG_LABEL_FN     LLM=Not HSHD / human=HSHD / ST=Not HSHD
        → no keyword change (ST was correct; only the human label was wrong)
LLM_OVERRIDE  all other combos
        → add entries with LLM label
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional, Union

import numpy as np
import pandas as pd

from .llm_judge import LLMJudge
from .sentence_transformer_classifier import (
    ClassificationResult,
    SentenceTransformerClassifier,
)

logger = logging.getLogger(__name__)

CHECKPOINT_INTERVAL = 5    # keyword additions between each checkpoint + ST refresh
MAX_CONVERGENCE_PASSES = 10


class CaseType(str, Enum):
    AGREEMENT_HSHD     = "AGREEMENT_HSHD"
    AGREEMENT_NOT_HSHD = "AGREEMENT_NOT_HSHD"
    ST_FALSE_NEGATIVE  = "ST_FALSE_NEGATIVE"   # Case 3
    WRONG_LABEL_FP     = "WRONG_LABEL_FP"      # Case 4
    ST_FALSE_POSITIVE  = "ST_FALSE_POSITIVE"   # Case 5
    WRONG_LABEL_FN     = "WRONG_LABEL_FN"      # Case 6
    LLM_OVERRIDE       = "LLM_OVERRIDE"
    UNCLEAR            = "UNCLEAR"


@dataclass
class PipelineResult:
    golden_df:           pd.DataFrame
    keyword_df:          pd.DataFrame
    unknown_silver_df:   pd.DataFrame
    unclear_keywords_df: pd.DataFrame
    final_accuracy:      float
    convergence_passes:  int


class Pipeline:
    def __init__(
        self,
        st_classifier: SentenceTransformerClassifier,
        llm_judge:     LLMJudge,
    ):
        self.st  = st_classifier
        self.llm = llm_judge

        self._golden:            list[dict] = []
        self._unknown_silver:    list[dict] = []
        self._unclear_keywords:  list[dict] = []

        self._kw_additions:     int = 0   # additions since last checkpoint/refresh
        self._total_processed:  int = 0
        self._output_dir:       Optional[Path] = None

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(
        self,
        silver_df:         pd.DataFrame,
        keyword_df:        pd.DataFrame,
        output_dir:        Optional[Path] = None,
        silver_embeddings: Optional[Union[np.ndarray, str, Path]] = None,
    ) -> PipelineResult:
        """
        Parameters
        ----------
        silver_df : pd.DataFrame
            The silver dataset. Must contain columns 'source_input' and 'human_label'.
        keyword_df : pd.DataFrame
            The initial labeled keyword list.
        output_dir : Path | str | None
            If provided, all 4 output CSVs are checkpointed here every
            CHECKPOINT_INTERVAL keyword additions.
        silver_embeddings : np.ndarray | str | Path | None
            Pre-computed L2-normalised embeddings for silver_df rows, in the
            same row order. Accepts:
              * numpy.ndarray  shape (N, D)         — use directly
              * str / Path to a .pkl file           — loaded via
                SentenceTransformerClassifier.load_silver_embeddings()
            When provided the initial batch ST forward pass is skipped,
            which dramatically speeds up large silver datasets.
            When None (default), embeddings are computed on the fly.
        """
        self._output_dir      = Path(output_dir) if output_dir else None
        self._keyword_df      = keyword_df.copy()
        self._golden          = []
        self._unknown_silver  = []
        self._unclear_keywords = []
        self._kw_additions    = 0
        self._total_processed = 0

        self.st.load_keyword_list(self._keyword_df)

        # ── Resolve silver embeddings ──────────────────────────────────
        resolved_embs: Optional[np.ndarray] = None
        if silver_embeddings is not None:
            if isinstance(silver_embeddings, (str, Path)):
                logger.info("Loading pre-computed silver embeddings from %s …", silver_embeddings)
                resolved_embs = SentenceTransformerClassifier.load_silver_embeddings(
                    pkl_path=silver_embeddings,
                    silver_df=silver_df,
                )
            elif isinstance(silver_embeddings, np.ndarray):
                logger.info(
                    "Using supplied silver embeddings array  (shape %s).",
                    silver_embeddings.shape,
                )
                resolved_embs = silver_embeddings
            else:
                raise TypeError(
                    f"silver_embeddings must be a numpy.ndarray, str, or Path, "
                    f"not {type(silver_embeddings)}."
                )

            if len(resolved_embs) != len(silver_df):
                raise ValueError(
                    f"silver_embeddings has {len(resolved_embs)} rows but "
                    f"silver_df has {len(silver_df)} rows."
                )

        # ── PHASE 1 & 2 ───────────────────────────────────────────────
        self._run_iteration(
            silver_df,
            phase_label="PHASE 1+2 (silver dataset)",
            precomputed_embs=resolved_embs,
        )

        # ── PHASE 3: convergence ─────────────────────────────────────
        golden_df, convergence_passes = self._convergence_loop()

        eval_result = self.st.evaluate(golden_df)
        logger.info(
            "Final ST accuracy: %.1f%% (%d/%d correct) after %d convergence pass(es).",
            eval_result["accuracy"] * 100,
            int(eval_result["accuracy"] * eval_result["total"]),
            eval_result["total"],
            convergence_passes,
        )

        # Final checkpoint
        if self._output_dir:
            self._save_checkpoint(golden_df, label="FINAL")

        return PipelineResult(
            golden_df           = golden_df,
            keyword_df          = self._keyword_df,
            unknown_silver_df   = pd.DataFrame(self._unknown_silver),
            unclear_keywords_df = pd.DataFrame(self._unclear_keywords),
            final_accuracy      = eval_result["accuracy"],
            convergence_passes  = convergence_passes,
        )

    # ------------------------------------------------------------------
    # One full iteration: batch ST → split → LLM on mismatches
    # ------------------------------------------------------------------

    def _run_iteration(
        self,
        df: pd.DataFrame,
        phase_label: str = "",
        precomputed_embs: Optional[np.ndarray] = None,
    ) -> None:
        n_total = len(df)
        texts   = df["source_input"].astype(str).tolist()

        logger.info("")
        logger.info("=" * 65)
        if phase_label:
            logger.info("%s", phase_label)

        if precomputed_embs is not None:
            logger.info(
                "Using pre-computed embeddings for %d samples (skipping encode) …",
                n_total,
            )
            st_results  = self.st.classify_batch_from_embeddings(precomputed_embs)
            batch_embs  = precomputed_embs          # already have the matrix
        else:
            logger.info("Running batch ST encode+score on %d samples …", n_total)
            # return_embeddings=True — free; the matrix was computed anyway
            st_results, batch_embs = self.st.classify_batch(
                texts, show_progress_bar=True, return_embeddings=True
            )

        # ── Prime the golden embedding cache for EVERY silver text ────────
        # Cost: one dict write per sample — O(N), no model.encode() calls.
        # Benefit: all future get_similar_golden_samples() and classify()
        # calls for these texts become pure cache hits.
        for text, emb in zip(texts, batch_embs):
            self.st.prime_golden_cache(text, emb)
        logger.info("Golden embedding cache primed for %d texts.", n_total)

        # ── Split match / mismatch ────────────────────────────────────
        matches    = []   # (row_series, st_result)
        mismatches = []

        for idx, (_, row) in enumerate(df.iterrows()):
            st_r = st_results[idx]
            if row["human_label"] == st_r.label:
                matches.append((row, st_r))
            else:
                mismatches.append((row, st_r))

        pct_match    = len(matches)    / n_total * 100
        pct_mismatch = len(mismatches) / n_total * 100

        logger.info("")
        logger.info(
            "New Iteration: %d samples  |  %d (%.1f%%) Match  |  %d (%.1f%%) Not Match",
            n_total,
            len(matches),    pct_match,
            len(mismatches), pct_mismatch,
        )
        logger.info("=" * 65)

        # ── Matches → golden directly ─────────────────────────────────
        logger.info("Adding %d matching samples to golden dataset …", len(matches))
        for row, st_r in matches:
            case = (
                CaseType.AGREEMENT_HSHD
                if row["human_label"] == "HSHD"
                else CaseType.AGREEMENT_NOT_HSHD
            )
            self._append_golden(
                source_input=str(row["source_input"]),
                human_label=str(row["human_label"]),
                st_label=st_r.label,
                st_kw=st_r.most_similar_keyword or "",
                st_score=st_r.similarity_score,
                llm_label=None,
                llm_reasoning="Human and ST agree — no LLM call.",
                llm_keyword=None,
                case=case,
                final_label=str(row["human_label"]),
            )
            self._total_processed += 1

        # ── Mismatches → LLM ─────────────────────────────────────────
        n_mm = len(mismatches)
        logger.info("")
        logger.info("Processing %d mismatch(es) with LLM …", n_mm)

        for i, (row, st_r) in enumerate(mismatches, start=1):
            src   = str(row["source_input"])
            human = str(row["human_label"])

            logger.info(
                "  [%d/%d | total %d/%d]  '%s'  human=%-10s  ST=%-10s"
                "  (closest: '%s', %.4f)",
                i, n_mm,
                self._total_processed + 1, n_total,
                src, human, st_r.label,
                st_r.most_similar_keyword or "", st_r.similarity_score,
            )

            self._process_mismatch(src, human, st_r)
            self._total_processed += 1

    # ------------------------------------------------------------------
    # LLM arbitration for one mismatch
    # ------------------------------------------------------------------

    def _process_mismatch(
        self, source_input: str, human_label: str, st_r: ClassificationResult
    ) -> None:
        st_label = st_r.label
        st_kw    = st_r.most_similar_keyword or ""
        st_score = st_r.similarity_score

        similar_golden = self.st.get_similar_golden_samples(
            source_input, self._golden, top_k=3
        )
        llm_result  = self.llm.judge(
            source_input=source_input,
            human_label=human_label,
            st_label=st_label,
            st_most_similar_kw=st_kw,
            st_similarity_score=st_score,
            similar_golden_samples=similar_golden,
        )
        llm_label   = llm_result["label"]
        llm_reason  = llm_result.get("reasoning", "")
        llm_keyword = llm_result.get("generated_keyword", source_input)

        # ── UNCLEAR branch ────────────────────────────────────────────
        if llm_label == "unclear":
            logger.info(
                "    -> UNCLEAR  routing to unknown_silver / unclear_keywords."
            )
            self._unknown_silver.append({
                "source_input":        source_input,
                "human_label":         human_label,
                "st_label":            st_label,
                "st_most_similar_kw":  st_kw,
                "st_similarity_score": st_score,
                "llm_reasoning":       llm_reason,
                "llm_generated_kw":    llm_keyword,
            })
            self._unclear_keywords.append({
                "keyword":        llm_keyword,
                "source_input":   source_input,
                "llm_reasoning":  llm_reason,
            })
            return

        # ── Classified ────────────────────────────────────────────────
        case = self._determine_case(human_label, st_label, llm_label)

        logger.info(
            "    -> LLM=%-10s  case=%-22s  kw='%s'",
            llm_label, case.value, llm_keyword,
        )

        self._handle_keyword_update(case, source_input, llm_keyword, llm_label)
        self._append_golden(
            source_input=source_input,
            human_label=human_label,
            st_label=st_label,
            st_kw=st_kw,
            st_score=st_score,
            llm_label=llm_label,
            llm_reasoning=llm_reason,
            llm_keyword=llm_keyword,
            case=case,
            final_label=llm_label,
        )

    # ------------------------------------------------------------------
    # Case routing
    # ------------------------------------------------------------------

    @staticmethod
    def _determine_case(
        human_label: str, st_label: str, llm_label: str
    ) -> CaseType:
        h, s, l_ = human_label, st_label, llm_label
        if l_ == "HSHD"     and h == "HSHD"     and s == "Not HSHD": return CaseType.ST_FALSE_NEGATIVE
        if l_ == "HSHD"     and h == "Not HSHD" and s == "HSHD":     return CaseType.WRONG_LABEL_FP
        if l_ == "Not HSHD" and h == "Not HSHD" and s == "HSHD":     return CaseType.ST_FALSE_POSITIVE
        if l_ == "Not HSHD" and h == "HSHD"     and s == "Not HSHD": return CaseType.WRONG_LABEL_FN
        return CaseType.LLM_OVERRIDE

    # ------------------------------------------------------------------
    # Keyword-list update
    # ------------------------------------------------------------------

    def _handle_keyword_update(
        self,
        case:              CaseType,
        source_input:      str,
        generated_keyword: str,
        llm_label:         str,
    ) -> None:
        """
        Cases that update the keyword list:
            ST_FALSE_NEGATIVE, ST_FALSE_POSITIVE, LLM_OVERRIDE
        Per-update rule: add BOTH
            (a) the original source_input  with llm_label
            (b) the LLM canonical keyword  with llm_label  (if different)

        Cases that do NOT update:
            WRONG_LABEL_FP, WRONG_LABEL_FN  — ST was correct; silver label wrong
        """
        if case not in (
            CaseType.ST_FALSE_NEGATIVE,
            CaseType.ST_FALSE_POSITIVE,
            CaseType.LLM_OVERRIDE,
        ):
            return

        added = False
        # (a) original input
        if self._add_single_keyword(source_input, llm_label, "LLM_original_input"):
            added = True
        # (b) canonical keyword (skip if same as source_input)
        if generated_keyword.lower() != source_input.lower():
            if self._add_single_keyword(generated_keyword, llm_label, "LLM_generated"):
                added = True

        if added:
            # Checkpoint + ST refresh every CHECKPOINT_INTERVAL additions
            if self._kw_additions >= CHECKPOINT_INTERVAL:
                logger.info(
                    "    [Checkpoint] %d keyword additions — refreshing ST & saving files.",
                    self._kw_additions,
                )
                self.st.load_keyword_list(self._keyword_df)
                if self._output_dir:
                    self._save_checkpoint(pd.DataFrame(self._golden))
                self._kw_additions = 0

    def _add_single_keyword(
        self, keyword: str, label: str, source: str
    ) -> bool:
        """Add keyword if not already present. Returns True if added."""
        existing = self._keyword_df["keyword"].str.lower().tolist()
        if keyword.lower() in existing:
            logger.debug("    Keyword '%s' already in list — skipping.", keyword)
            return False

        new_row = pd.DataFrame([{"keyword": keyword, "label": label, "source": source}])
        self._keyword_df = pd.concat([self._keyword_df, new_row], ignore_index=True)
        self._kw_additions += 1

        logger.info(
            "    [+] [%-10s] '%s'  (%s)  additions since refresh: %d/%d",
            label, keyword, source,
            self._kw_additions, CHECKPOINT_INTERVAL,
        )
        return True

    # ------------------------------------------------------------------
    # Golden-dataset append
    # ------------------------------------------------------------------

    def _append_golden(
        self,
        source_input: str, human_label: str,
        st_label: str, st_kw: str, st_score: float,
        llm_label: Optional[str], llm_reasoning: str, llm_keyword: Optional[str],
        case: CaseType, final_label: str,
    ) -> None:
        self._golden.append({
            "source_input":        source_input,
            "human_label":         human_label,
            "st_label":            st_label,
            "st_most_similar_kw":  st_kw,
            "st_similarity_score": st_score,
            "llm_label":           llm_label or "",
            "llm_reasoning":       llm_reasoning,
            "llm_generated_kw":    llm_keyword or "",
            "case_type":           case.value,
            "final_label":         final_label,
        })

    # ------------------------------------------------------------------
    # Convergence loop
    # ------------------------------------------------------------------

    def _convergence_loop(self) -> tuple[pd.DataFrame, int]:
        logger.info("")
        logger.info("=" * 65)
        logger.info("PHASE 3: Convergence loop (target: 100%% ST accuracy)")
        logger.info("=" * 65)

        golden_df = pd.DataFrame(self._golden)

        for pass_num in range(1, MAX_CONVERGENCE_PASSES + 1):
            eval_result = self.st.evaluate(golden_df)
            accuracy    = eval_result["accuracy"]
            errors      = eval_result["errors"]
            total       = eval_result["total"]

            logger.info("")
            logger.info(
                "  Convergence pass %d — ST accuracy %.1f%% (%d/%d correct, %d errors)",
                pass_num, accuracy * 100,
                int(accuracy * total), total, len(errors),
            )

            if accuracy == 1.0:
                logger.info("  Converged after %d pass(es).", pass_num - 1)
                return golden_df, pass_num - 1

            # Build a mini-df of error rows and re-run the iteration logic
            error_inputs = [e["source_input"] for e in errors]
            error_rows   = golden_df[golden_df["source_input"].isin(error_inputs)].copy()

            logger.info("  Fixing %d remaining mismatch(es) with LLM …", len(errors))

            for err_idx, err in enumerate(errors, start=1):
                src       = err["source_input"]
                expected  = err["expected"]
                predicted = err["predicted"]

                logger.info(
                    "    [%d/%d]  '%s'  ST=%s  expected=%s",
                    err_idx, len(errors), src, predicted, expected,
                )

                row_mask  = golden_df["source_input"] == src
                human_lbl = golden_df.loc[row_mask, "human_label"].iloc[0]

                st_r      = self.st.classify(src)
                similar_golden = self.st.get_similar_golden_samples(
                    src, golden_df.to_dict("records"), top_k=3
                )
                llm_result  = self.llm.judge(
                    source_input=src,
                    human_label=human_lbl,
                    st_label=predicted,
                    st_most_similar_kw=st_r.most_similar_keyword or "",
                    st_similarity_score=st_r.similarity_score,
                    similar_golden_samples=similar_golden,
                )
                llm_label   = llm_result["label"]
                llm_keyword = llm_result.get("generated_keyword", src)

                if llm_label == "unclear":
                    logger.info(
                        "    LLM still unclear for '%s' — skipping this pass.", src
                    )
                    continue

                case = self._determine_case(human_lbl, predicted, llm_label)
                self._handle_keyword_update(case, src, llm_keyword, llm_label)

                golden_df.loc[row_mask, "llm_label"]        = llm_label
                golden_df.loc[row_mask, "llm_reasoning"]    = llm_result.get("reasoning", "")
                golden_df.loc[row_mask, "llm_generated_kw"] = llm_keyword
                golden_df.loc[row_mask, "case_type"]        = case.value
                golden_df.loc[row_mask, "final_label"]      = llm_label

            # Flush remaining additions
            if self._kw_additions > 0:
                self.st.load_keyword_list(self._keyword_df)
                self._kw_additions = 0

            if self._output_dir:
                self._save_checkpoint(golden_df, label=f"convergence_pass_{pass_num}")

        logger.warning(
            "Did not converge after %d passes. Final accuracy: %.1f%%",
            MAX_CONVERGENCE_PASSES,
            self.st.evaluate(golden_df)["accuracy"] * 100,
        )
        return golden_df, MAX_CONVERGENCE_PASSES

    # ------------------------------------------------------------------
    # Checkpoint save
    # ------------------------------------------------------------------

    def _save_checkpoint(
        self,
        golden_df: pd.DataFrame,
        label: str = "",
    ) -> None:
        if self._output_dir is None:
            return
        self._output_dir.mkdir(exist_ok=True)
        ts = datetime.now().strftime("%H:%M:%S")

        golden_df.to_csv(self._output_dir / "golden_dataset.csv", index=False)
        self._keyword_df.to_csv(self._output_dir / "final_keyword_list.csv", index=False)

        pd.DataFrame(self._unknown_silver).to_csv(
            self._output_dir / "unknown_silver_dataset.csv", index=False
        )
        pd.DataFrame(self._unclear_keywords).to_csv(
            self._output_dir / "unclear_keywords.csv", index=False
        )

        logger.info(
            "[CHECKPOINT %s%s]  golden=%d  unclear=%d  keywords=%d",
            ts,
            f"  ({label})" if label else "",
            len(golden_df),
            len(self._unknown_silver),
            len(self._keyword_df),
        )
