"""
LLM-based judge that arbitrates between the human label and the sentence-
transformer prediction.

JSON schema (reasoning is LAST so truncated output is detected early)
----------------------------------------------------------------------
{
  "label"            : "HSHD" | "Not HSHD" | "unclear",
  "generated_keyword": "<canonical keyword string>",
  "reasoning"        : "<one or two sentence explanation>"
}

Incomplete-output policy
------------------------
Any of the following makes the response "unclear" for human review:
  * JSON cannot be parsed
  * "label" key missing or unrecognised value
  * "generated_keyword" key missing or empty string
  * "reasoning" key missing, empty, or shorter than MIN_REASONING_CHARS
  * The raw response is truncated (closing brace absent)

Putting reasoning last means the model commits to label + keyword before
writing the justification — the two most actionable fields are therefore
present even if the stream cuts off early, which we still catch as unclear.

The model object must expose `.generate(prompt: str) -> str`.
"""

import json
import logging
import re

logger = logging.getLogger(__name__)

MIN_REASONING_CHARS = 15   # fewer chars than this → treat as incomplete
_VALID_LABELS = {"HSHD", "Not HSHD", "unclear"}

_SYSTEM_PROMPT = """\
You are a data-privacy expert who classifies whether a term represents
Highly Sensitive Human Data (HSHD).

HSHD — personal information that can uniquely identify or reveal sensitive
details about a natural person. Examples:
  - Government-issued IDs  (SSN, Passport, Driver License, National ID, SIN, NIN)
  - Tax IDs that map to SSN (Tax ID, EIN for sole proprietors)
  - Financial identifiers   (Bank Account Number, Credit Card Number)
  - Biometric identifiers   (Fingerprint, Face ID, DNA)
  - Health identifiers      (Medical Record Number, Medicare Number)
  - Immigration / residency (Resident Registration Number, Alien Number)
  - Date of Birth used as an identifier

NOT HSHD — identifiers that do not map to a person's sensitive data. Examples:
  - Product / inventory codes   (SKU, Product ID, Serial Number)
  - Order / logistics codes     (Order Number, Tracking Number, Invoice Number)
  - Internal system references  (Transaction Reference, Batch ID)
  - Membership / loyalty codes  (Loyalty Card, Club ID — unless tied to financials)
  - Organisational role codes   (Employee Badge Number, Social Worker ID)
  - Social-media handles        (not tied to government identity)

UNCLEAR — use ONLY when you genuinely cannot decide even after applying all
signals. Examples of legitimate unclear cases:
  - Term is too generic to infer data type (e.g. "Reference Number")
  - Classification differs across jurisdictions with no context to resolve it
  - Human label and ST signal strongly contradict with no resolution path

Decision heuristic for borderline cases:
  "Could a bad actor use this term alone to locate or harm a specific person?"
  Yes → HSHD.  No → Not HSHD.  Truly unknowable → unclear.
"""

_USER_PROMPT_TEMPLATE = """\
## Task
Classify the following input as HSHD, Not HSHD, or unclear.

### Input
"{source_input}"

### Available signals
| Signal | Value |
|--------|-------|
| Human label | {human_label} |
| ST closest keyword | "{st_most_similar_kw}" |
| Cosine similarity | {st_similarity_score:.4f} |
| ST prediction | {st_label} |

### Context: similar curated samples
{similar_samples_block}

### Response format (JSON only, no markdown fences)
Return EXACTLY this structure — reasoning comes last:

{{
  "label": "<HSHD|Not HSHD|unclear>",
  "generated_keyword": "<canonical keyword that best represents this concept>",
  "reasoning": "<one or two sentences explaining your decision>"
}}

Rules:
- "generated_keyword" must be a clean, title-cased phrase (e.g. "Tax ID", not "tax id number").
- If label is "unclear", still provide a best-guess canonical keyword.
- Do NOT add any text outside the JSON object.
"""


class LLMJudge:
    def __init__(self, model):
        """
        Parameters
        ----------
        model : Any
            Object with `.generate(prompt: str) -> str`.
            Production: wraps the GPT-OSS-120B server API.
        """
        self.model = model

    def judge(
        self,
        source_input: str,
        human_label: str,
        st_label: str,
        st_most_similar_kw: str,
        st_similarity_score: float,
        similar_golden_samples: list[dict],
    ) -> dict:
        """
        Returns dict with keys:
          label             : "HSHD" | "Not HSHD" | "unclear"
          generated_keyword : str
          reasoning         : str
        """
        similar_block = self._format_similar_samples(similar_golden_samples)

        full_prompt = (
            _SYSTEM_PROMPT
            + "\n\n"
            + _USER_PROMPT_TEMPLATE.format(
                source_input=source_input,
                human_label=human_label,
                st_most_similar_kw=st_most_similar_kw or "N/A",
                st_similarity_score=st_similarity_score,
                st_label=st_label,
                similar_samples_block=similar_block,
            )
        )

        logger.debug("LLM prompt for '%s':\n%s", source_input, full_prompt)
        raw = self.model.generate(full_prompt)
        logger.debug("LLM raw response for '%s': %s", source_input, raw)

        return self._parse_response(raw, source_input)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _format_similar_samples(samples: list[dict]) -> str:
        if not samples:
            return "(none yet)"
        lines = [
            f'- "{s["source_input"]}" -> **{s["final_label"]}** (human: {s["human_label"]})'
            for s in samples
        ]
        return "\n".join(lines)

    @staticmethod
    def _parse_response(raw: str, source_input: str) -> dict:
        """
        Parse the LLM response.  Mark as unclear on ANY sign of incompleteness:
          - Missing closing brace (truncated stream)
          - Missing required fields
          - Unrecognised label
          - Reasoning too short (< MIN_REASONING_CHARS)
        """
        def _unclear(reason: str) -> dict:
            logger.warning("Marking '%s' unclear: %s", source_input, reason)
            return {
                "label": "unclear",
                "generated_keyword": source_input,
                "reasoning": f"[AUTO-UNCLEAR] {reason}",
            }

        # ── 1. Basic completeness: must contain a closing brace ─────────
        cleaned = re.sub(r"```(?:json)?", "", raw).strip()
        if not cleaned.endswith("}"):
            return _unclear("Response appears truncated (no closing brace).")

        # ── 2. Extract JSON ────────────────────────────────────────────
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not match:
            return _unclear("No JSON object found in response.")

        try:
            obj = json.loads(match.group())
        except json.JSONDecodeError as exc:
            return _unclear(f"JSON parse error: {exc}")

        # ── 3. Validate label ──────────────────────────────────────────
        raw_label = str(obj.get("label", "")).strip()
        if raw_label.upper() == "HSHD":
            label = "HSHD"
        elif raw_label.lower() in ("not hshd", "nothshd", "not_hshd"):
            label = "Not HSHD"
        elif raw_label.lower() == "unclear":
            label = "unclear"
        elif not raw_label:
            return _unclear("'label' field is missing or empty.")
        else:
            return _unclear(f"Unrecognised label value: '{raw_label}'.")

        # ── 4. Validate generated_keyword ─────────────────────────────
        gen_kw = str(obj.get("generated_keyword", "")).strip()
        if not gen_kw:
            return _unclear("'generated_keyword' field is missing or empty.")

        # ── 5. Validate reasoning (must exist and be substantive) ──────
        reasoning = str(obj.get("reasoning", "")).strip()
        if not reasoning:
            return _unclear("'reasoning' field is missing.")
        if len(reasoning) < MIN_REASONING_CHARS:
            return _unclear(
                f"'reasoning' is too short ({len(reasoning)} chars < "
                f"{MIN_REASONING_CHARS} min)."
            )

        return {
            "label":             label,
            "generated_keyword": gen_kw,
            "reasoning":         reasoning,
        }
