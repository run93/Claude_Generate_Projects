"""
Mock GPT-OSS-120B model for development / testing.

Exposes `.generate(prompt: str) -> str` identical to the production API.
JSON fields are returned in the required order:
    label  ->  generated_keyword  ->  reasoning  (reasoning is LAST)

This matches the prompt schema so the real model sees a consistent example.

Production swap:
    from your_api_client import ServerModel
    model = ServerModel(endpoint="...", api_key="...")
    judge = LLMJudge(model)
"""

import json
import logging
import re

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Knowledge tables
# ---------------------------------------------------------------------------

_HSHD_PATTERNS = [
    "ssn", "social security", "tax id", "tax identification",
    "national id", "national identification", "national insurance",
    "social insurance", "passport", "driver license", "driver's license",
    "date of birth", "dob", "bank account", "credit card",
    "medical record", "medicare", "biometric", "fingerprint",
    "face id", "facial", "dna", "resident registration",
    "alien number", "immigration", "government issued id",
    "government id", "birth certificate", "sin number",
    "nin ", "national insurance number",
]

_NOT_HSHD_PATTERNS = [
    "product sku", "sku", "order number", "order reference",
    "invoice", "serial number", "tracking number", "transaction reference",
    "loyalty card", "loyalty points", "batch", "item code",
    "employee badge", "badge number", "social worker",
    "social media", "social network", "social club", "club membership",
]

# Inputs the mock considers genuinely unclear
_UNCLEAR_PATTERNS = [
    "reference number",   # too generic
    "voter registration", # jurisdiction-dependent
    "club card",          # loyalty vs financial card boundary
]

_CANONICAL: dict[str, str] = {
    "ssn":                          "SSN",
    "passport number":              "Passport Number",
    "credit card no.":              "Credit Card Number",
    "tax id":                       "Tax ID",
    "social insurance number":      "Social Insurance Number",
    "national insurance number":    "National Insurance Number",
    "birth certificate":            "Birth Certificate",
    "social security card":         "Social Security Card",
    "employee badge number":        "Employee Badge Number",
    "social worker number":         "Social Worker Number",
    "social media account id":      "Social Media Account ID",
    "product sku":                  "Product SKU",
    "order reference number":       "Order Reference Number",
    "loyalty card number":          "Loyalty Card Number",
    "government issued id":         "Government Issued ID",
    "medicare number":              "Medicare Number",
    "resident registration number": "Resident Registration Number",
    "tracking number":              "Tracking Number",
    "fingerprint id":               "Fingerprint ID",
    "social club membership id":    "Social Club Membership ID",
    "reference number":             "Reference Number",
    "voter registration id":        "Voter Registration ID",
    "club card number":             "Club Card Number",
}

# Reasoning strings — written AFTER label + keyword, matching real LLM behaviour
_REASONING: dict[str, str] = {
    # HSHD
    "tax id": (
        "Tax ID maps directly to SSN for US individuals and sole proprietors, "
        "making it Highly Sensitive Human Data."
    ),
    "social insurance number": (
        "Social Insurance Number (SIN) is Canada's equivalent of the US SSN — "
        "a government-issued personal identifier and therefore HSHD."
    ),
    "national insurance number": (
        "National Insurance Number (NIN) is the UK national identifier, "
        "functionally equivalent to SSN — clearly HSHD."
    ),
    "birth certificate": (
        "A birth certificate number is an official government document uniquely "
        "tied to an individual's identity — HSHD."
    ),
    "medicare number": (
        "Medicare number is a health-insurance identifier directly linked to "
        "an individual's identity and medical history — HSHD."
    ),
    "resident registration number": (
        "Resident Registration Number is the Korean national ID equivalent — "
        "a government-issued personal identifier and therefore HSHD."
    ),
    "social security card": (
        "Social Security Card directly refers to the SSN-bearing document; "
        "the human label appears incorrect — this is HSHD."
    ),
    # Not HSHD
    "social worker number": (
        "Social Worker Number is an organisational role identifier, not a "
        "government-issued personal ID — Not HSHD."
    ),
    "social media account id": (
        "Social Media Account ID is a platform-specific handle, not tied to "
        "government or financial identity — Not HSHD."
    ),
    "employee badge number": (
        "Employee Badge Number is an internal corporate identifier with no "
        "inherent personal sensitivity; human label appears incorrect — Not HSHD."
    ),
    "social club membership id": (
        "Social Club Membership ID identifies club membership, not a person's "
        "sensitive data — Not HSHD."
    ),
    # Unclear
    "reference number": (
        "The term 'Reference Number' is too generic to classify without "
        "additional business context — could be an order reference (Not HSHD) "
        "or a case reference tied to a person (HSHD). Flagged for human review."
    ),
    "voter registration id": (
        "Voter Registration ID is a government identifier, but its sensitivity "
        "varies: protected in some jurisdictions, public record in others. "
        "Cannot classify without knowing the applicable regulatory context."
    ),
    "club card number": (
        "Club Card Number could be a loyalty card (Not HSHD) or a financial "
        "club card linked to a bank account (HSHD). Insufficient context to "
        "decide — flagged for human review."
    ),
}


class MockLLMModel:
    """
    Simulates GPT-OSS-120B.
    Returns JSON with fields in order: label -> generated_keyword -> reasoning.
    """

    def generate(self, prompt: str) -> str:
        source_input = self._extract_source_input(prompt)
        label        = self._classify(source_input)
        canonical    = _CANONICAL.get(source_input.lower(), source_input)
        reasoning    = self._get_reasoning(source_input, label)

        # Fields ordered: label, generated_keyword, reasoning (reasoning last)
        response = json.dumps({
            "label":             label,
            "generated_keyword": canonical,
            "reasoning":         reasoning,
        }, ensure_ascii=False)

        logger.debug("MockLLM '%s' -> %s", source_input, label)
        return response

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_source_input(prompt: str) -> str:
        match = re.search(r'"([^"]+)"\s*\n\n###\s*Available', prompt)
        if match:
            return match.group(1)
        match = re.search(r'"([^"]+)"', prompt)
        return match.group(1) if match else ""

    @staticmethod
    def _classify(text: str) -> str:
        lower = text.lower()
        for pat in _UNCLEAR_PATTERNS:
            if pat in lower:
                return "unclear"
        for pat in _NOT_HSHD_PATTERNS:
            if pat in lower:
                return "Not HSHD"
        for pat in _HSHD_PATTERNS:
            if pat in lower:
                return "HSHD"
        return "Not HSHD"

    @staticmethod
    def _get_reasoning(text: str, label: str) -> str:
        lower = text.lower()
        for key, reason in _REASONING.items():
            if key in lower:
                return reason
        if label == "HSHD":
            return f'"{text}" is a personal identifier that qualifies as HSHD.'
        if label == "Not HSHD":
            return f'"{text}" does not constitute personally sensitive data — Not HSHD.'
        return (
            f'"{text}" is ambiguous without additional business context — '
            "flagged for human review."
        )
