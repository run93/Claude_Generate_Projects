"""
app.py — Manual keyword review web server.

No LLM is used. The workflow is:
  1. Load golden dataset (initialised from silver_dataset.csv on first run).
  2. Load keyword list (initialised from initial_keyword_list.csv on first run).
  3. Run the ST classifier on the golden dataset.
  4. Surface mismatches (ST prediction ≠ final_label) in the browser UI.
  5. For each mismatch the user picks one of three actions:
       A — Flip the sample's final_label in the golden dataset.
       B — Add a new Positive keyword to the keyword list.
       C — Add a new Negative keyword to the keyword list.
  6. The user can re-run the ST model and recalculate metrics at any time.

Usage
-----
    python app.py
Then open http://localhost:5000 in a browser.
"""

import threading
from pathlib import Path

import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
)

from src.sentence_transformer_classifier import SentenceTransformerClassifier

# ---------------------------------------------------------------------------
# Paths — always relative to this file so the server works regardless of
# which directory it is launched from.
# ---------------------------------------------------------------------------

BASE_DIR   = Path(__file__).resolve().parent
DATA_DIR   = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

GOLDEN_PATH  = OUTPUT_DIR / "golden_dataset.csv"
KEYWORD_PATH = OUTPUT_DIR / "keyword_list.csv"

# ---------------------------------------------------------------------------
# Flask app
# ---------------------------------------------------------------------------

app = Flask(__name__)

# ---------------------------------------------------------------------------
# Global in-memory state
# ---------------------------------------------------------------------------

_classifier: SentenceTransformerClassifier | None = None
_golden_df:  pd.DataFrame | None = None
_keyword_df: pd.DataFrame | None = None
_mismatches: list[dict]  = []
_stats:      dict        = {}
_run_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Data initialisation
# ---------------------------------------------------------------------------

def load_datasets() -> None:
    """Load (or initialise) golden dataset and keyword list from disk."""
    global _golden_df, _keyword_df

    # Golden dataset -------------------------------------------------------
    if GOLDEN_PATH.exists():
        _golden_df = pd.read_csv(GOLDEN_PATH)
        if "final_label" not in _golden_df.columns:
            _golden_df["final_label"] = _golden_df.get("human_label", "Not HSHD")
    else:
        silver_df  = pd.read_csv(DATA_DIR / "silver_dataset.csv")
        _golden_df = silver_df[["source_input", "human_label"]].copy()
        _golden_df["final_label"] = _golden_df["human_label"]
        if "notes" in silver_df.columns:
            _golden_df["notes"] = silver_df["notes"]
        _golden_df.to_csv(GOLDEN_PATH, index=False)

    # Keyword list ---------------------------------------------------------
    if KEYWORD_PATH.exists():
        _keyword_df = pd.read_csv(KEYWORD_PATH)
    else:
        _keyword_df = pd.read_csv(DATA_DIR / "initial_keyword_list.csv")
        _keyword_df.to_csv(KEYWORD_PATH, index=False)


def get_classifier() -> SentenceTransformerClassifier:
    global _classifier
    if _classifier is None:
        _classifier = SentenceTransformerClassifier(
            model_name="BAAI/bge-m3", threshold=0.70
        )
    return _classifier

# ---------------------------------------------------------------------------
# Core: run ST classifier and compute metrics
# ---------------------------------------------------------------------------

def run_st() -> None:
    """Classify all golden samples; populate _mismatches and _stats."""
    global _mismatches, _stats

    clf = get_classifier()
    clf.load_keyword_list(_keyword_df)

    texts = _golden_df["source_input"].astype(str).tolist()
    results = clf.classify_batch(texts, show_progress_bar=False)

    mismatches: list[dict] = []
    y_true: list[int] = []
    y_pred: list[int] = []

    for i, (_, row) in enumerate(_golden_df.iterrows()):
        res         = results[i]
        final_label = str(row["final_label"])
        st_label    = res.label

        y_true.append(1 if final_label == "HSHD" else 0)
        y_pred.append(1 if st_label    == "HSHD" else 0)

        if st_label != final_label:
            mismatch_type = (
                "False Positive"  # ST=HSHD,     final=Not HSHD
                if st_label == "HSHD"
                else "False Negative"  # ST=Not HSHD, final=HSHD
            )
            mismatches.append({
                "id":                int(i),
                "source_input":      str(row["source_input"]),
                "final_label":       final_label,
                "st_label":          st_label,
                "mismatch_type":     mismatch_type,
                "st_score":          round(float(res.similarity_score), 4),
                "st_keyword":        res.most_similar_keyword or "",
                "best_hshd_kw":      res.best_hshd_keyword    or "",
                "best_hshd_score":   round(float(res.best_hshd_score), 4),
                "best_not_hshd_kw":  res.best_not_hshd_keyword or "",
                "best_not_hshd_score": round(float(res.best_not_hshd_score), 4),
            })

    _mismatches = mismatches

    total = len(y_true)
    if total == 0:
        _stats = {"accuracy": 0, "precision": 0, "recall": 0, "f1": 0,
                  "total": 0, "mismatch_count": 0}
        return

    _stats = {
        "accuracy":        round(float(accuracy_score(y_true, y_pred)),                       4),
        "precision":       round(float(precision_score(y_true, y_pred, zero_division=0)),     4),
        "recall":          round(float(recall_score(y_true, y_pred, zero_division=0)),        4),
        "f1":              round(float(f1_score(y_true, y_pred, zero_division=0)),            4),
        "total":           total,
        "mismatch_count":  len(mismatches),
    }

# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/status")
def api_status():
    """Return current state without re-running the classifier."""
    return jsonify({
        "has_run":    bool(_stats),
        "mismatches": _mismatches,
        "stats":      _stats,
        "keywords":   _keyword_df.to_dict("records") if _keyword_df is not None else [],
    })


@app.route("/api/run", methods=["POST"])
def api_run():
    """Re-run the ST classifier and recalculate all metrics."""
    with _run_lock:
        run_st()
    return jsonify({
        "ok":         True,
        "mismatches": _mismatches,
        "stats":      _stats,
        "keywords":   _keyword_df.to_dict("records"),
    })


@app.route("/api/action", methods=["POST"])
def api_action():
    """Apply a manual action to a mismatch.

    Body JSON:
        action  : "A" | "B" | "C"
        id      : int  (index into _golden_df for action A)
        keyword : str  (required for B and C)
        label   : str  (required for B and C — "HSHD" or "Not HSHD")
    """
    global _golden_df, _keyword_df

    data   = request.get_json(force=True)
    action = data.get("action", "").upper()
    row_id = data.get("id")

    # ------------------------------------------------------------------
    # Action A — flip final_label
    # ------------------------------------------------------------------
    if action == "A":
        if row_id is None:
            return jsonify({"ok": False, "error": "Missing row id"}), 400
        row_id = int(row_id)
        if row_id not in _golden_df.index:
            return jsonify({"ok": False, "error": f"Row {row_id} not found"}), 404

        old_label = str(_golden_df.at[row_id, "final_label"])
        new_label = "Not HSHD" if old_label == "HSHD" else "HSHD"
        _golden_df.at[row_id, "final_label"] = new_label
        _golden_df.to_csv(GOLDEN_PATH, index=False)

        return jsonify({
            "ok":       True,
            "message":  f"Label flipped: {old_label} → {new_label}",
            "new_label": new_label,
        })

    # ------------------------------------------------------------------
    # Actions B / C — add keyword
    # ------------------------------------------------------------------
    if action in ("B", "C"):
        keyword = str(data.get("keyword", "")).strip()
        label   = str(data.get("label",   "")).strip()

        if not keyword:
            return jsonify({"ok": False, "error": "Keyword cannot be empty"}), 400
        if label not in ("HSHD", "Not HSHD"):
            return jsonify({"ok": False, "error": "Label must be 'HSHD' or 'Not HSHD'"}), 400

        existing = _keyword_df["keyword"].str.lower().tolist()
        if keyword.lower() in existing:
            return jsonify({
                "ok":    False,
                "error": f"Keyword '{keyword}' already exists in the list",
            }), 409

        new_row    = pd.DataFrame([{"keyword": keyword, "label": label, "source": "manual"}])
        _keyword_df = pd.concat([_keyword_df, new_row], ignore_index=True)
        _keyword_df.to_csv(KEYWORD_PATH, index=False)

        return jsonify({
            "ok":      True,
            "message": f"Added keyword '{keyword}' [{label}]",
        })

    return jsonify({"ok": False, "error": f"Unknown action '{action}'"}), 400


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    PORT = 5000

    print("Loading datasets …")
    load_datasets()
    print(
        f"  Golden dataset : {GOLDEN_PATH}  ({len(_golden_df)} rows)\n"
        f"  Keyword list   : {KEYWORD_PATH} ({len(_keyword_df)} rows)\n"
    )
    print(f"Starting server on port {PORT} …")
    print("(ST model loads on first 'Run' — may take a moment.)\n")

    app.run(debug=False, host="0.0.0.0", port=PORT)
